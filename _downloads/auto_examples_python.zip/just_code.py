# -*- coding: utf-8 -*-
"""
A short Python script
=====================

A script that is not executed when gallery is generated but nevertheless
gets included as an example.
Doing a list
"""

# Code source: Óscar Nájera
# License: BSD 3 clause
from __future__ import print_function
print([i for i in range(10)])
